f x = x + x;

main = print (f + f); -- operator + not defined for functions
