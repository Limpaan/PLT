main = print (1 < 2) ;  -- result 1
