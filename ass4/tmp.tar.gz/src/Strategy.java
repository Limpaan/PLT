public enum Strategy {
    CallByName,
    CallByValue
}
