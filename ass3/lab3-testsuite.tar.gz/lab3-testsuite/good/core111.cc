int main () {
  printInt(readInt()-1);
  return 0;
}
