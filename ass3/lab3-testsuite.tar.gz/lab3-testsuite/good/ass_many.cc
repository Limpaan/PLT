int main () {
  int x, j, i;
  j = i = 6;
  printInt(i+j);
  return 0;
}

