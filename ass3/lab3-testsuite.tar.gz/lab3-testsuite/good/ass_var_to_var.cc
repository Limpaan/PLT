int main() {
  int x = 0;
  int y = x;
  return 0;
}
