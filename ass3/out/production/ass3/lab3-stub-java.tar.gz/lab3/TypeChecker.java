import CPP.Absyn.*;
import java.util.*;

public class TypeChecker
{
  // Entry point for annotating type checker.

  public Program typecheck(Program p) {
    throw new TypeException("Sorry, no type checker implemented yet.");
  }
}
