public class TypeException extends RuntimeException {

    public TypeException(String msg) {
        super(msg);
    }

}
