public class test {

    public static void main(String[] args) {
        int x = 1;
        System.out.println((x=10)+(x++)+x);
    }
}
