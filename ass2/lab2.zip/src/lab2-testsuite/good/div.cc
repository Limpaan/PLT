int main() {
  printInt(5 / 3);
  return 0;
}
