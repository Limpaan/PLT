int main () {
  int uw = 0;
  if (uw-- >= 0) 0;
  else 0;
  printInt (uw);
  return 0;
}
