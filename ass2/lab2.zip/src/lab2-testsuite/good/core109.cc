int main() {
  int j = 4;

  {
	printInt(j);
  }

  return j;
}
