int main () {
	if (0 >= 0) printInt(0);
	else printInt(1);
  if (1 >= 1) printInt(2);
  else printInt(3);
  if (2 <= 2) printInt(4);
  else printInt(5);
  if (0 <= 0) printInt(6);
  else printInt(7);
  return 0;
}
