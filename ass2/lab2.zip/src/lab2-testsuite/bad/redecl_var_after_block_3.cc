int main() {
	int x;
	{
		int y;
	}
	int x;
	return 0;
}
