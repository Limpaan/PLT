void foo(int x) {

}

void foo1() {
  int x;
}

int foo2() {
  return x;
}

int main() {
  return foo2();
}
