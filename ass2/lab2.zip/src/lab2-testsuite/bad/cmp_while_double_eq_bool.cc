// Compare double with boolean.

int main() {
  while (2.0 == true) {
	  return 1;
  }
  return 0 ;
}
