int main () {
	int x;
	if (3 != true)
		x = 1;
	else {}
	return 0;
}
