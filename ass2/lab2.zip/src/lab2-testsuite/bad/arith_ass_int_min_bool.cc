int main () {
  bool x = 0-false;
  return 0;
}
