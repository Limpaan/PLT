int main() {
        int x;
        x = true;
        return 1;
}
