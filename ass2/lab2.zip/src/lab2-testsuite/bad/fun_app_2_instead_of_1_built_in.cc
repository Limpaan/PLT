int main() {
  printDouble(1.0, 2.0);
  return 0;
}
