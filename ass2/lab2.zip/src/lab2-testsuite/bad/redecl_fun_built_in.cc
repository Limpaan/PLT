void printInt(int x) {}

int main() {
  printInt(5);

  return 0;
}
