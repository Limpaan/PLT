int main() {
  while (1.0) {

  }
  return 0;
}
