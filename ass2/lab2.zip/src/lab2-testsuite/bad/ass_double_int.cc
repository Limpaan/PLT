// Assigning int to double variable.

int main () {
 double x = 1;
 return 0 ;
}